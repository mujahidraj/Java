import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Start1 
{
	public static void main(String [] args)
	{
		home1 home = new home1();
		
	}
}